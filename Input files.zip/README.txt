VASP input files for calculation of total energy and electronic density of states of La_{2/3}Ca_{1/3}MnO_3.

Description:
CONTCAR(s): Fully optimized structures in the A-AFM and FM phases.
INCAR_*_relax: INCAR for structure optimizations.
INCAR_*_static: INCAR for DOS calculations.
POSCAR_*_0: Structures at the "0" strain state in A-AFM and FM phases.
POSCAR_*_DOS: Structures used to calculate the electronic DOS in the paper.
